package com.mcgill.ecse321.GameShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameShopApplication {
	public static void main(String[] args) {
		SpringApplication.run(GameShopApplication.class, args);
	}
}