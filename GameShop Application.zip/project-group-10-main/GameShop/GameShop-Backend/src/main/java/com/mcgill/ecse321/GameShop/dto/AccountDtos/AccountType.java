package com.mcgill.ecse321.GameShop.dto.AccountDtos;

public enum AccountType {
    CUSTOMER,
    MANAGER,
    EMPLOYEE
}
