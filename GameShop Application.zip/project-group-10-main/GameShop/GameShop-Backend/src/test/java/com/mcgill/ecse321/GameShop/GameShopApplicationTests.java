package com.mcgill.ecse321.GameShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
