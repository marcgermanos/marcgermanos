# :factory::ship: ECSE223 WareFlow Project: Team N

_(Edit this file as needed, then remove this sentence)._

## Project Overview

_Provide a one-sentence overview of your project here._

For more information about the WareFlow application, please consult the [wiki](../../wiki).

## Team Members

| Name          | GitHub username |
| ------------- | --------------- |
| Team Member A | ...             |
| Team Member B | ...             |
| Team Member C | ...             |
| Team Member D | ...             |
| Team Member E | ...             |
| Team Member F | ...             |